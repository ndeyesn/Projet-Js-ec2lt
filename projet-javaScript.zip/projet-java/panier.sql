

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";




CREATE TABLE `products_tbl` (
  `id` int(10) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `new_price` varchar(250) NOT NULL,
  `product_img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



INSERT INTO `products_tbl` (`id`, `product_name`, `description`, `new_price`, `product_img`) VALUES
(1, 'lunette', 'lunette anti-reflet', '10000',  'img/tommy.jpg'),
(2, 'calvinKlein', 'calvinKlein teinté', '4000',  'img/calvinKlein.jpg'),
(3, 'gucci', 'Gucci moins cher', '2000',  'img/gucci.jpg'),
(4, 'perce', 'La classe', '20000', 'img/perce.jpg'),
(5, 'rayban', 'lunette moins cher', '4000', 'img/rayban.jpg'),
(6, 'habilles blanc bebe', 'tres jolie pour vos petites princesses', '2500', 'img/ma6.jpg'),
(7, 'chaussure bebe', 'Des chaussures en coton', '5000','img/ma9.jpg'),
(8, 'habilles blanc bebe', 'Habillement tres chic', '3000','img/ma7.jpg'),
(9, 'habilles bleu blanc bebe', 'pour vos princes', '1500','img/ma8.jpg');


ALTER TABLE `products_tbl`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `products_tbl`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
