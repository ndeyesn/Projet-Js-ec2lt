<?php 
            session_start();
            $product_ids = array();
            if (isset($_POST['add_to_cart'])) {
               if (isset($_SESSION['panier'])) {
                   $count = count ($_SESSION['panier']);
                   $products_ids = array_column($_SESSION['panier'], 'id');
                    if (!in_array(filter_input(INPUT_GET, 'id'), $product_ids)) {
                            $_SESSION['panier'][$count] = array(

                                'id' => filter_input(INPUT_GET, 'id'),
                                'product_name' => filter_input(INPUT_POST, 'product_name'),
                                'description' => filter_input(INPUT_POST, 'description'),
                                'new_price' => filter_input(INPUT_POST, 'new_price'),
                                'quantity' => filter_input(INPUT_POST, 'quantity'),
                                'product_img' => filter_input(INPUT_POST, 'product_img')
                            );
                    }else {
                            for ($i = 0 ; $i < count ($product_ids); $i++){
                                    if ($product_ids[$i]  == filter_input(INPUT_GET, 'id')) {
                                            $_SESSION['panier'][$i]['quantity'] += filter_input(INPUT_POST, 'quantity');
                                    }
                            }
                    }
               }else {
                   $_SESSION['panier'][0] = array(
                    'id' => filter_input(INPUT_GET, 'id'),
                    'product_name' => filter_input(INPUT_POST, 'product_name'),
                    'description' => filter_input(INPUT_POST, 'description'),
                    'new_price' => filter_input(INPUT_POST, 'new_price'),
                    'quantity' => filter_input(INPUT_POST, 'quantity'),
                    'product_img' => filter_input(INPUT_POST, 'product_img')
                   );
               }
            }
            if (filter_input(INPUT_GET, 'action') == 'supprimer') {
                    foreach ($_SESSION['panier'] as $key => $produit) {
                        if ($produit['id'] == filter_input(INPUT_GET, 'id')) {
                            unset($_SESSION['panier'][$key]);
                        }
                    }
                    $_SESSION['panier'] =array_values($_SESSION['panier']);
            }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>panier</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="css/vendors/@fortawesome/fontawesome-free/css/all.min.css">
</head>
</body>
<nav class="navbar navbar-expand-md navbar-light bg-light">
    <div class="container-fluid">
        <a href="#" class="navbar-brand">
            <h4>SENEGALESE SHOPPING</h4>
        </a>
            <button class="navbar-toggler" type="button"
            data-toggle="collapse"
            data-target = "#collapse"
            aria-controls = "navbarCollapse"
            aria-expanded="false"
            aria-label="Toggle navigation"
            >
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapse">
                <ul class="navbar-nav mr-auto mb-2 mb-md-0">

                <li class="nav-item active">
                        <a href="index.php" class="nav-link">Accueil</a>
                    </li>
                </ul>
            </div>
    </div>
</nav>
<div class="container-fluid md-5">
    <div class="row px-5 py-2">  
    <br>
    <hr>
        <div class="col-md-7">
        <a href="index.php" class="btn btn-success btn-block">Continuer vos achats</a>
            <h4>Mon panier</h4>
            <?php
                if (!empty ($_SESSION['panier'])):
                    $total = 0 ;
                    foreach ($_SESSION['panier'] as $key => $produit):         
            ?>      
            <div class="card px-3 mb-5">          
                <div class="card-body">
                    <div class="row"> 
                    <div class="col-md-4">
                    <img src="<?php echo $produit ['product_img'];?>" class="img-fluid px-5 prdimg "  alt="produit image">
                    </div>
                        <div class="col-md-4">
                            <h4><?php echo $produit ['product_name'];?></h4>
                            <h6><b>Description : </b><?php echo $produit ['description'];?></h6>
                            <p></p>
                            <h5 class="secondary"><?php echo $produit ['new_price'];?></small>
                            </h5>
                        </div>
                        <div class="col-md-4 py-5 px-5">
                           <a href="checkout.php?action=supprimer&id=<?php echo $produit ['id'];?>">
                                <div class="btn btn-danger">Retirer</div>
                           </a>
                        </div>
                    </div>
                </div>
            </div>
               <?php 
                    $total = $total + ($produit['quantity'] * $produit['new_price']);
                    endforeach;
               ?>
    <?php endif;  ?>
        </div> 
        <?php 
            if(!empty ($_SESSION['panier'])):
                if(count($_SESSION['panier']) > 0);
        ?>       
<div class="col-md-5 py-5 px5">
    <div class="card">
        <div class="card-body">
            <b>Details des produits à acheter</b>
            <hr>
            <div class="row">
                <div class="col-md-5 py-4">
                    <h5><b>Montant à payer</b></h5>
                </div>
                <div class="col-md-5 py-4">
                    <h5 class="float-right"><b><?php echo $total;?></b></h5>
                </div>
            </div>
                </div>
            </div>  
        </div>   
    </div>
                <?php 
                        endif;
                ?>
    </div>
</div>
<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>