<?php 
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>site-e-commerce</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="css/vendors/@fortawesome/fontawesome-free/css/all.min.css">
    
</head>
</body>
<nav class="navbar navbar-expand-md navbar-light bg-light">
    <div class="container-fluid">
        <a href="#" class="navbar-brand">
            <h4>SENEGALESE SHOPPING</h4>
        </a>
            <button class="navbar-toggler" type="button"
            data-toggle="collapse"
            data-target = "#collapse"
            aria-controls = "navbarCollapse"
            aria-expanded="false"
            aria-label="Toggle navigation"
            >
            <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapse">
                <ul class="navbar-nav mr-auto mb-2 mb-md-0">

                    <li class="nav-item active">
                        <a href="index.php" class="nav-link">Accueil</a>
                    </li>
                    <li class="nav-item ">
                        <a href="checkout.php" class="nav-link"><i class="fa fa-shopping-cart"></i>Panier</a>
                    </li>
                </ul>
            </div>
    </div>
</nav>
<div class="container">
 <div class="row align-items-center">
    <div class="col-lg-12 py-5">
        <div class="card px-3">
            <div class="card-body">
                <h3><marquee behavior="alternate"> BIENVENUE SUR LE SITE DE VENTE</marquee></h3>
            </div>
        
        </div>
    </div>
 </div>
</div>
   
    <div class="card section-intro px-4">
    
    <div class="card-body">
        <div class="card-header  items-header">
            <h4><b>Mes Produits</b></h4>
        </div>
        <div class=" row py-3 items">
        
     <?php      
       require "includes/conn.php";

            $query = "SELECT * FROM products_tbl";
            $result = mysqli_query($conn, $query);

            if($result):

                if(mysqli_num_rows ($result) > 0):
                    while ($produit = mysqli_fetch_assoc($result)):
     ?>
            <div class="col-lg-4">
                <form action="checkout.php?action=add&id=<?php echo $produit ['id'];?>" 
                method="post" enctype="multipart/form-data">
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <div>
                                <img src="<?php echo $produit['product_img'];?>" class="img-fluid px-5 prdimg">
                            </div>
                            <h6 class="secondary"><?php echo $produit['product_name'];?></h6>
                            <h4 class="secondary"><?php echo $produit['description'];?></h4>
                            <h2 class="secondary"><small><?php echo $produit['new_price'];?>&nbspFCCA</small>
                            </h2>
                            <input type="number" class="form-control mb-3" name="quantity" value="1">
                            <input type="hidden" name="id" value="<?php echo $produit['id'];?>">
                            <input type="hidden" name="product_img" value="<?php echo $produit['product_img'];?>">
                            <input type="hidden" name="product_name" value="<?php echo $produit['product_name'];?>">
                            <input type="hidden" name="description" value="<?php echo $produit['description'];?>">
                            <input type="hidden" name="new_price" value="<?php echo $produit['new_price'];?>">
                            <button type="submit" name="add_to_cart" class="btn btn-warning">
                            <i class="fa fa-shopping-cart"></i>
                               AJOUT-PANIER
                            </button>
                        </div>
                    </div>
                </form>
            </div>
      <?php 
                    endwhile;
                endif;
            endif;
      ?>
        </div>
    </div>
    </div>
</div>
    </div>
</div>
<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>